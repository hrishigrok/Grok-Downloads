ecg_sensor_1 = None


import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()

device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()

def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()

from grok_i2c_peripherals import init_i2c_bus
from grok_i2c_peripherals import read_adc
from grok_i2c_peripherals import write_analog
init_i2c_bus()
import time


def read_ECG_Values(analog_Channel):
    Value = (read_adc(analog_Channel))
    return Value

import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time


while True:
  ecg_sensor_1 = read_ECG_Values(1)
  device["mobile_messages"].append({'type' : 'text','value' : '---------------------------------------------------','color' : '#ffffff'})
  device["mobile_messages"].append({'type' : 'text', 'value' : ('ECG Readings : ' + str(ecg_sensor_1)), 'color' : '#ff0000'})

  device_sensor(device)
  device["mobile_messages"] = []
  time.sleep(0.5)
