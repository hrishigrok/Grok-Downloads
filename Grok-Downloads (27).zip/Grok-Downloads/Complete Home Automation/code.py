direction = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time


GPIO.setup((8), GPIO.IN)
GPIO.setup((16), GPIO.IN)
servo = (17)
GPIO.setup(servo,GPIO.OUT)
p=GPIO.PWM(servo,50)
p.start(2.5)
GPIO.setup((18), GPIO.IN)
GPIO.setup((22), GPIO.OUT)
GPIO.output((22), GPIO.HIGH)

p.ChangeDutyCycle(4)
p.ChangeDutyCycle(0)

flag3 = 0
flag4 = 0

in1 = (19)
in2 = (26)

GPIO.setup(in1,GPIO.OUT)
GPIO.setup(in2,GPIO.OUT)
GPIO.output(in1,GPIO.LOW)
GPIO.output(in2,GPIO.LOW)


def roof_stop():
	GPIO.output(in1,GPIO.LOW)
	GPIO.output(in2,GPIO.LOW)

	
def roof_open():
  GPIO.output(in1,GPIO.HIGH)
  GPIO.output(in2,GPIO.LOW)
  time.sleep(6)
  roof_stop()

  
def roof_close():
  GPIO.output(in1,GPIO.LOW)
  GPIO.output(in2,GPIO.HIGH)
  time.sleep(6)
  roof_stop()

flag1 = 0
flag2 = 1



in3 = (24)
in4 = (25)
flag5 = 0
flag6 = 1

GPIO.setup(in3,GPIO.OUT)
GPIO.setup(in4,GPIO.OUT)
GPIO.output(in3,GPIO.LOW)
GPIO.output(in4,GPIO.LOW)


def curt_stop():
	GPIO.output(in3,GPIO.LOW)
	GPIO.output(in4,GPIO.LOW)

	
def curt_close():
  GPIO.output(in3,GPIO.HIGH)
  GPIO.output(in4,GPIO.LOW)
  time.sleep(13)
  curt_stop()
  
def curt_open():
  GPIO.output(in3,GPIO.LOW)
  GPIO.output(in4,GPIO.HIGH)
  time.sleep(13)
  curt_stop()
 
while True:
  raindrop_sensor_1 = GPIO.input(8)
  raindrop_sensor_1 = check_with_simulator2(raindrop_sensor_1,'raindrop_sensor_1', sim_device)
  
  motionsensor_1 = (GPIO.input(16))
  motionsensor_1 = check_with_simulator2(motionsensor_1,'motionsensor_1', sim_device)
  
  ldr_sensor_1 = (GPIO.input(18))
  ldr_sensor_1 = check_with_simulator2(ldr_sensor_1,'ldr_sensor_1', sim_device)
  
  
  
  if raindrop_sensor_1 == 1:
    device["mobile_messages"].append({'type' : 'text','value' : 'Rain Detected Roof Close','color' : '#ffcccc'})
    if flag1 == 0:
      roof_close()
      time.sleep(2)
      flag1 = 1
      flag2 = 0
    
  elif raindrop_sensor_1 == 0:
    device["mobile_messages"].append({'type' : 'text','value' : 'Not Raining Roof Open','color' : '#99ff99'})
    if flag2 == 0:
      roof_open()
      time.sleep(2)
      flag2 = 1
      flag1 = 0
      
      
      
  if motionsensor_1 == 1:
    device["mobile_messages"].append({'type' : 'text','value' : 'Motion Detected Gate Open','color' : '#ccccff'})
    if flag3 == 0:
      p.ChangeDutyCycle(1)
      time.sleep(1)
      p.ChangeDutyCycle(0)
      flag3 = 1
    flag4 = 0
  elif motionsensor_1 == 0:
    device["mobile_messages"].append({'type' : 'text','value' : 'Gate Close','color' : '#ffffcc'})
    if flag4 == 0:
      p.ChangeDutyCycle(4)
      time.sleep(1)
      p.ChangeDutyCycle(0)
      flag4 = 1
    flag3 = 0
    
    
  if ldr_sensor_1 == 0:
    device["mobile_messages"].append({'type' : 'text','value' : 'Lights ON','color' : '#ffffff'})
    GPIO.output(22, GPIO.HIGH)
    
    if flag5 == 0:
      curt_open()
      flag5 = 1
    flag6 = 0
    time.sleep(0.5)
    
  elif ldr_sensor_1 == 1:
    device["mobile_messages"].append({'type' : 'text','value' : 'Lights Off','color' : '#ffccff'})
    GPIO.output(22, GPIO.LOW)
    
    if flag6 == 0:
      curt_close()
      flag6 = 1
      
    flag5 = 0
    time.sleep(0.5)

  time.sleep(1)
  device_sensor(device)
  device["mobile_messages"] = []
  
  
