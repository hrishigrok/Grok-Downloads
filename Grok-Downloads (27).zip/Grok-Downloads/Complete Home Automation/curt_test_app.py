import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time

in1 = (24)
in2 = (25)

GPIO.setup(in1,GPIO.OUT)
GPIO.setup(in2,GPIO.OUT)
GPIO.output(in1,GPIO.LOW)
GPIO.output(in2,GPIO.LOW)


# def curt_stop():
# 	GPIO.output(in1,GPIO.LOW)
# 	GPIO.output(in2,GPIO.LOW)

	
def curt_close():
  GPIO.output(in1,GPIO.HIGH)
  GPIO.output(in2,GPIO.LOW)
  time.sleep(13)
  curt_stop()
  
def curt_open():
  GPIO.output(in1,GPIO.LOW)
  GPIO.output(in2,GPIO.HIGH)
  time.sleep(13)
  curt_stop()
  
  
curt_open()
time.sleep(10)
curt_close()



