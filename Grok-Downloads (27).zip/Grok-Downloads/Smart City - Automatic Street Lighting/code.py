light_sensor_1 = None
light_sensor_2 = None
light_sensor_3 = None
irsensor_1 = None


import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()

device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()

def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()


import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
GPIO.setup((8), GPIO.IN)
GPIO.setup((16), GPIO.IN)
GPIO.setup((17), GPIO.IN)
GPIO.setup((24), GPIO.OUT)
GPIO.setup((25), GPIO.OUT)
GPIO.setup((27), GPIO.OUT)
while True:
  light_sensor_1 = (GPIO.input(8))
  light_sensor_1 = check_with_simulator2(light_sensor_1,'light_sensor_1', sim_device)
  light_sensor_2 = (GPIO.input(16))
  light_sensor_2 = check_with_simulator2(light_sensor_2,'light_sensor_2', sim_device)
  light_sensor_3 = (GPIO.input(17))
  light_sensor_3 = check_with_simulator2(light_sensor_3,'light_sensor_3', sim_device)
  irsensor_1 = (GPIO.input(18))
  irsensor_1 = check_with_simulator2(irsensor_1,'irsensor_1', sim_device)
  device["mobile_messages"].append({'type' : 'text','value' : '---------------------------------------------','color' : '#ffffff'})
  print('------------------------------------------')
  if light_sensor_3 == 0:
    GPIO.output(24, True)
    print('Light 3 ON')
    device["mobile_messages"].append({'type' : 'text','value' : 'Light 3 ON','color' : '#ffff99'})
  else:
    GPIO.output(24, False)
    print('Light 3 OFF')
    device["mobile_messages"].append({'type' : 'text','value' : 'Light 3 OFF','color' : '#ffcccc'})
  if light_sensor_2 == 0:
    GPIO.output(25, True)
    print('Light 2 ON')
    device["mobile_messages"].append({'type' : 'text','value' : 'Light 2 ON','color' : '#ffff99'})
  else:
    GPIO.output(25, False)
    print('Light 2 OFF')
    device["mobile_messages"].append({'type' : 'text','value' : 'Light 2 OFF','color' : '#ffcccc'})
  if light_sensor_1 == 0:
    GPIO.output(27, True)
    print('Light 1 ON')
    device["mobile_messages"].append({'type' : 'text','value' : 'Light 1 ON','color' : '#ffff99'})
  else:
    GPIO.output(27, False)
    print('Light 1 OFF')
    device["mobile_messages"].append({'type' : 'text','value' : 'Light 1 OFF','color' : '#ffcccc'})

  device_sensor(device)
  device["mobile_messages"] = []
  time.sleep(1)
