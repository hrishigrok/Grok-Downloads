irsensor_1 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
from picamera import PiCamera
import time
GPIO.setup((7), GPIO.IN)
camera = PiCamera()
while True:
  irsensor_1 = (GPIO.input(7))
  irsensor_1 = check_with_simulator2(irsensor_1,'irsensor_1', sim_device)
  if irsensor_1 == 1:
    print('Intruder detected')
    device["mobile_messages"].append({'type' : 'text','value' : 'Intruder detected','color' : '#ff6666'})
    camera.start_preview()
    time.sleep(3)
    camera.capture('/home/pi/Desktop/Grok-Downloads/image.jpg')
    image_url = grokLib.upload_image('/home/pi/Desktop/Grok-Downloads/image.jpg')
    device['mobile_messages'].append({'type' : 'image','source' : image_url,'state' : True})
    camera.stop_preview()
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(5)
  elif irsensor_1 == 0:
    print('No Intruder detected')
    device["mobile_messages"].append({'type' : 'text','value' : 'No Intruder detected','color' : '#33ff33'})
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(1)