input_relay_1 = None
Power_Factor = None
Frequency = None
Energy = None
Power = None
Current = None
Voltage = None


import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()

device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()

def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()


import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
import time
import json
import serial
import modbus_tk.defines as cst
from modbus_tk import modbus_rtu
serial = serial.Serial(port='/dev/ttyS0',baudrate=9600,bytesize=8,parity='N',stopbits=1,xonxoff=0)
master = modbus_rtu.RtuMaster(serial)
master.set_timeout(2.0)
master.set_verbose(True)
dict_payload = dict()
GPIO.setup((7), GPIO.OUT)
GPIO.output((7), GPIO.HIGH)
def calculate_power_meter_data():
	try:
		data = master.execute(1, cst.READ_INPUT_REGISTERS, 0, 10)
		dict_payload["voltage"]= data[0] / 10.0
		dict_payload["current_A"] = (data[1] + (data[2] << 16)) / 1000.0 # [A]
		dict_payload["power_W"] = (data[3] + (data[4] << 16)) / 10.0 # [W]
		dict_payload["energy_KWh"] = (data[5] + (data[6] << 16))/1000 # [KWh]
		dict_payload["frequency_Hz"] = data[7] / 10.0 # [Hz]
		dict_payload["power_factor"] = data[8] / 100.0
		str_payload = json.dumps(dict_payload, indent=2)
		print(str_payload)
		powerReadings = [dict_payload["voltage"],dict_payload["current_A"],dict_payload["power_W"],dict_payload["energy_KWh"],dict_payload["frequency_Hz"],dict_payload["power_factor"]]
	except:
		powerReadings =[0,0,0,0,0,0]

	return powerReadings

def read_data():
	power_meter_read_data = {}
	data = calculate_power_meter_data()
	power_meter_read_data["voltage"] = data[0]
	power_meter_read_data["current"] = data[1]
	power_meter_read_data["power"] = data[2]
	power_meter_read_data["energy"] = data[3]
	power_meter_read_data["frequency"] = data[4]
	power_meter_read_data["powerFactor"] = data[5]

	return power_meter_read_data

GPIO.output(7, GPIO.HIGH)
while True:
  input_relay_1 = (7)
  input_relay_1 = check_with_simulator2(input_relay_1,'input_relay_1', sim_device)
  if input_relay_1 == 1:
    print('Turn ON Light')
    device["mobile_messages"].append({'type' : 'text','value' : 'Turn ON Light','color' : '#ffffff'})
    GPIO.output(7, GPIO.LOW)
    time.sleep(1)
  elif input_relay_1 == 0:
    print('Turn OFF Light')
    device["mobile_messages"].append({'type' : 'text','value' : 'Turn OFF Light','color' : '#c0c0c0'})
    GPIO.output(7, GPIO.HIGH)
    time.sleep(1)
  power_meter_read_data = read_data()
  Power_Factor = power_meter_read_data["powerFactor"]
  device["mobile_messages"].append({'type' : 'text', 'value' : ('Power Factor : ' + str(Power_Factor)), 'color' : '#ff0000'})
  Frequency = power_meter_read_data["frequency"]
  device["mobile_messages"].append({'type' : 'text', 'value' : ('Frequency : ' + str(Frequency)), 'color' : '#ff9900'})
  Energy = power_meter_read_data["energy"]
  device["mobile_messages"].append({'type' : 'text', 'value' : ('Energy : ' + str(Energy)), 'color' : '#ffff00'})
  Power = power_meter_read_data["power"]
  device["mobile_messages"].append({'type' : 'text', 'value' : ('Power : ' + str(Power)), 'color' : '#33ff33'})
  Current = power_meter_read_data["current"]
  device["mobile_messages"].append({'type' : 'text', 'value' : ('Current : ' + str(Current)), 'color' : '#00cccc'})
  Voltage = power_meter_read_data["voltage"]
  device["mobile_messages"].append({'type' : 'text', 'value' : ('Voltage: ' + str(Voltage)), 'color' : '#cc33cc'})
  device["mobile_messages"].append({'type' : 'text','value' : '---------------------------------------------','color' : '#ffffff'})

  device_sensor(device)
  device["mobile_messages"] = []
  time.sleep(1)
