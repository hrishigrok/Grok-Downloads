set_time1 = None
rtc_1 = None
moisturesensor_1 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import time
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
from grok_i2c_peripherals import init_i2c_bus
from grok_i2c_peripherals import init_rtc
from grok_i2c_peripherals import rtc_read_time
from grok_i2c_peripherals import rtc_read_date_str
from grok_i2c_peripherals import rtc_read_time_str
from grok_i2c_peripherals import rtc_write_time
from grok_i2c_peripherals import rtc_write_date
GPIO.setup((7), GPIO.IN)
GPIO.setup((23), GPIO.OUT)
GPIO.output((23), GPIO.HIGH)
init_i2c_bus()
time.sleep(1)
init_rtc()
time.sleep(0.2)
def calculate_current_time():
    hour = str(rtc_read_time()[0])
    minute = str(rtc_read_time()[1])
    second = str(rtc_read_time()[2])
    current_time = hour + ':' + minute
    return current_time
set_time1 = '01:38'
while True:
  rtc_1 = (calculate_current_time()
  )
  rtc_1 = check_with_simulator2(rtc_1,'rtc_1', sim_device)
  print(rtc_1)
  moisturesensor_1 = (GPIO.input(7))
  moisturesensor_1 = check_with_simulator2(moisturesensor_1,'moisturesensor_1', sim_device)
  if set_time1 == rtc_1:
    if moisturesensor_1 == 0:
      print('No moisture present...water pump ON')
      device["mobile_messages"].append({'type' : 'text','value' : 'No moisture present...water pump ON','color' : '#ffff00'})
      GPIO.output(23, GPIO.HIGH)
      device_sensor(device)
      device["mobile_messages"] = []
      time.sleep(1)
  if moisturesensor_1 == 1:
    print('Enough moisture present...water pump OFF')
    device["mobile_messages"].append({'type' : 'text','value' : 'Enough moisture present...water pump OFF','color' : '#66cccc'})
    GPIO.output(23, GPIO.LOW)
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(1)
  time.sleep(1)