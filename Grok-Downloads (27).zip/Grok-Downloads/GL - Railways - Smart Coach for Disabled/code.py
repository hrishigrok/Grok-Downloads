irsensor_1 = None
irsensor_2 = None
irsensor_3 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
GPIO.setup((8), GPIO.IN)
GPIO.setup((16), GPIO.IN)
GPIO.setup((17), GPIO.IN)
GPIO.setup((7), GPIO.OUT)
GPIO.setup((22), GPIO.OUT)
servo = (18)
GPIO.setup(servo,GPIO.OUT)
p=GPIO.PWM(servo,50)
p.start(2.5)
p.ChangeDutyCycle(2.5)
while True:
  irsensor_1 = (GPIO.input(8))
  irsensor_1 = check_with_simulator2(irsensor_1,'irsensor_1', sim_device)
  irsensor_2 = (GPIO.input(16))
  irsensor_2 = check_with_simulator2(irsensor_2,'irsensor_2', sim_device)
  irsensor_3 = (GPIO.input(17))
  irsensor_3 = check_with_simulator2(irsensor_3,'irsensor_3', sim_device)
  if irsensor_1 == 1 and irsensor_2 == 0:
    print('Train is Arriving on Platform.')
    device["mobile_messages"].append({'type' : 'text','value' : 'Train is Arriving on Platform.','color' : '#ff6666'})
    device_sensor(device)
    device["mobile_messages"] = []
    GPIO.output(22, True)
  elif irsensor_1 == 1 and irsensor_2 == 1:
    print('Train is on Platform.')
    device["mobile_messages"].append({'type' : 'text','value' : 'Train is on Platform.','color' : '#66ff99'})
    device_sensor(device)
    device["mobile_messages"] = []
    if irsensor_3 == 1:
      print('Alert!!...People nearby')
      device["mobile_messages"].append({'type' : 'text','value' : 'Alert!!...People nearby','color' : '#ffcccc'})
      device_sensor(device)
      device["mobile_messages"] = []
      GPIO.output(7, True)
      time.sleep(1)
      GPIO.output(7, False)
      p.ChangeDutyCycle(2.5)
    else:
      time.sleep(2) 
      GPIO.output(7, True)
      time.sleep(1)
      GPIO.output(7, False)  
      print('Ramp Open')
      device["mobile_messages"].append({'type' : 'text','value' : 'Ramp Open','color' : '#99ffff'})
      device_sensor(device)
      device["mobile_messages"] = []
      
      p.ChangeDutyCycle(7.5)
      time.sleep(5)
      print('Ramp Close')
      device["mobile_messages"].append({'type' : 'text','value' : 'Ramp Close','color' : '#99ffff'})
      device_sensor(device)
      device["mobile_messages"] = []
      GPIO.output(7, True)
      time.sleep(1)
      GPIO.output(7, False)
      p.ChangeDutyCycle(2.5)
  elif irsensor_1 == 0 and irsensor_2 == 1:
    print('Train is Departing')
    device["mobile_messages"].append({'type' : 'text','value' : 'Train is Departing','color' : '#ffff66'})
    device_sensor(device)
    device["mobile_messages"] = []
    GPIO.output(22, False)
  else:
    print('Train Departed')
    device["mobile_messages"].append({'type' : 'text','value' : 'Train Departed','color' : '#ffffff'})
    device_sensor(device)
    device["mobile_messages"] = []
    GPIO.output(22, False)
  time.sleep(1)