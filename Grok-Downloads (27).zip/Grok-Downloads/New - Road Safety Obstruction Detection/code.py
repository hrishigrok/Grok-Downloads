echosensor_1 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
GPIO.setup((21), GPIO.OUT)
GPIO.setup((9), GPIO.IN)
GPIO.setup((10), GPIO.OUT)
def calculate_distance(echo_pin,trigger_pin):
	GPIO.output(trigger_pin, True)
	time.sleep(0.00001)
	GPIO.output(trigger_pin, False)
	while GPIO.input(echo_pin) == 0:
		start = time.time()
	while GPIO.input(echo_pin) == 1:
		stop = time.time()
	measuredTime = stop - start
	distanceBothWays = measuredTime * 33112
	distance = distanceBothWays / 2
	print("Distance : {0:5.1f}cm".format(distance))
	return distance
while True:
  echosensor_1 = (calculate_distance((9),(10)))
  echosensor_1 = check_with_simulator2(echosensor_1,'echosensor_1', sim_device)
  if echosensor_1 > 50:
    device["mobile_messages"].append({'type' : 'text','value' : 'No object nearby','color' : '#33ff33'})
    GPIO.output(21, False)
  elif echosensor_1 < 10:
    device["mobile_messages"].append({'type' : 'text','value' : 'Object is very close!!!','color' : '#ff0000'})
    GPIO.output(21, True)
  else:
    device["mobile_messages"].append({'type' : 'text','value' : 'Nearby object detected','color' : '#ff9900'})
    GPIO.output(21, True)
    time.sleep(0.2)
    GPIO.output(21, False)
  device_sensor(device)
  device["mobile_messages"] = []
  time.sleep(2)