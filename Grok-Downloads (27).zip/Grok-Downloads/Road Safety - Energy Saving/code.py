irsensor_1 = None
irsensor_2 = None
irsensor_3 = None
irsensor_4 = None

import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time


def IR_SENSOR():
  global irsensor_1, ultrasonic_1, irsensor_2,irsensor_3,irsensor_4

  irsensor_1 = GPIO.input(8)
  irsensor_2 = GPIO.input(16)
  irsensor_3 = GPIO.input(17)
  irsensor_4 = GPIO.input(18)
  print(str(irsensor_1)+"   "+str(irsensor_2)+"  "+str(irsensor_3)+"  "+str(irsensor_4))

  if irsensor_4 == 1:
    GPIO.output(21, GPIO.LOW)
    GPIO.output(24, GPIO.HIGH)
    GPIO.output(25, GPIO.HIGH)
    GPIO.output(27, GPIO.LOW)
    time.sleep(1)

  elif irsensor_1 == 1:
    GPIO.output(21, GPIO.LOW)
    GPIO.output(24, GPIO.LOW)
    GPIO.output(25, GPIO.HIGH)
    GPIO.output(27, GPIO.HIGH)
    time.sleep(1)

  elif irsensor_2 == 1:
    GPIO.output(21, GPIO.HIGH)
    GPIO.output(24, GPIO.LOW)
    GPIO.output(25, GPIO.LOW)
    GPIO.output(27, GPIO.HIGH)
    time.sleep(1)

  elif irsensor_3 == 1:
    GPIO.output(21, GPIO.HIGH)
    GPIO.output(24, GPIO.HIGH)
    GPIO.output(25, GPIO.LOW)
    GPIO.output(27, GPIO.LOW)
    time.sleep(1)

#   else: 
#     GPIO.output(21, GPIO.HIGH)
#     GPIO.output(24, GPIO.HIGH)
#     GPIO.output(25, GPIO.HIGH)
#     GPIO.output(27, GPIO.HIGH)
#     time.sleep(0.5)


import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

#LED Relays
GPIO.setup((21), GPIO.OUT)
GPIO.output((21), GPIO.HIGH)
GPIO.setup((24), GPIO.OUT)
GPIO.output((24), GPIO.HIGH)
GPIO.setup((25), GPIO.OUT)
GPIO.output((25), GPIO.HIGH)
GPIO.setup((27), GPIO.OUT)
GPIO.output((27), GPIO.HIGH)


#IR Sensors
GPIO.setup((8), GPIO.IN)
GPIO.setup((16), GPIO.IN)
GPIO.setup((17), GPIO.IN)
GPIO.setup((18), GPIO.IN)


GPIO.output(21, GPIO.LOW)
GPIO.output(24, GPIO.LOW)
GPIO.output(25, GPIO.LOW)
GPIO.output(27, GPIO.LOW)

while True:
  IR_SENSOR()
  time.sleep(0.02)
