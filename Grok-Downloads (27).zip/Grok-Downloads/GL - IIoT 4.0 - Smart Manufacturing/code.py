import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()

status_1 = 0
mode_1 = 0
relay_1 = 0
echosensor_1 = 0
temperaturesensor_1 = 0
power_1 = 0
rtm_1 = 0



from grok_i2c_peripherals import init_i2c_bus
from grok_i2c_peripherals import write_analog
import os
import ast
import time
import math


TOTAL_STEPS_PER_RECIPE = 5
TOTAL_RECEPIES = 9

# 9 Recipes array
# Each recipe 5 steps
# index_0 -> RPM in %
# index_1 -> Duration in min
recipes_array =   [ [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ],
                    [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ],
                    [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ],
                    [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ],
                    [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ],
                    [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ],
                    [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ],
                    [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ],
                    [ [0, 0], [0, 0], [0, 0], [0, 0], [0, 0] ] ]

# Recipe running step details
run_status = False
recipe_cur_index = 0
recipe_cur_step = 0
recipe_cur_rpm = 0
recipe_cur_duration = 0

# present and duration
target_rpm = 0
target_duration = 0

# 1 min time tick detection
start_time = 0

# Interface for configuring recipies also memorise setting in file for future use 
# Input Args
# 1. recepi_num -> 1 to 9 for which step setting has to be done
# 2. step_num -> 1 to 5 for which rpm and duration setting has to be done
# 3. rpm_in_percent -> 0 to 700 (i.e. 70.0%), rpm setting for specified step of specified recipe
# 4. duration_in_min -> 0 to 9999 minutes, duration setting for specified step of specified recipe
def config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 0, duration_in_min = 0):
    global recipes_array
    # Check for file presence:
    # if present then read and overwrite specific settings
    # else creates file with default all '0' setting and overwrite specific settings

    # limit rpm
    if abs(rpm_in_percent) > 700:
        rpm_in_percent = 700
    # limit duration
    if abs(duration_in_min) > 9999:
        duration_in_min = 9999
    (recipes_array[recepi_num - 1][step_num - 1])[0] = abs(rpm_in_percent)
    (recipes_array[recepi_num - 1][step_num - 1])[1] = abs(duration_in_min)
    
    
# Interface to stop recipe in between for any critical situation
# It also stops motor by feeding 0 RPM
def stop_recipe():
    run_status = False
    target_rpm = 0
    write_analog(target_rpm)


# Interface to start recipe
# Input Args
# 1. recepi_num -> 1 to 9, recipe index which has to be run
# 2. step_num -> 1 to 5, step index from which specifies recipe has to be started
def start_recipe(recipe_num = 1, step_num = 1):
    global recipes_array, start_time, current_time
    global run_status, target_rpm, previous_rpm, target_duration
    global recipe_cur_index, recipe_cur_step, recipe_cur_rpm, recipe_cur_duration
    # Check for file presence:
    # if present then read 
    # else creates file with default all '0' setting and then read
    
    # As DAC is on I2C bus so init i2c before starting it
    init_i2c_bus()
    # if recipe is not running then only start it
    if run_status == False:
        run_status = True
        # stop motor on every start command as there may be previous some voltage present on DAC output
        target_rpm = 0
        write_analog(target_rpm)
        # limit recipe number
        if abs(recipe_num) > TOTAL_RECEPIES:
            recipe_num = TOTAL_RECEPIES
        # limit step number
        if abs(step_num) > TOTAL_STEPS_PER_RECIPE:
            step_num = TOTAL_STEPS_PER_RECIPE
        recipe_cur_index = abs(recipe_num - 1)         
        recipe_cur_step = abs(step_num - 1)
        update_recipe_step()
        write_analog(target_rpm)
        start_time = time.time()
        
#  updates running step parameters of the recipe
def update_recipe_step():
    global recipes_array
    global target_rpm, target_duration, previous_rpm
    global recipe_cur_index, recipe_cur_step, recipe_cur_rpm, recipe_cur_duration
    recipe_cur_rpm = (recipes_array[recipe_cur_index][recipe_cur_step])[0]
    target_duration = recipe_cur_duration = (recipes_array[recipe_cur_index][recipe_cur_step])[1]
    previous_rpm = target_rpm
    if recipe_cur_duration > 0:
        target_rpm += (recipe_cur_rpm - previous_rpm) // recipe_cur_duration
    print('step = ' + str(recipe_cur_step))
    print(target_duration)
    print(target_rpm)

    device["mobile_messages"].append({'type' : 'text', 'value' : target_rpm, 'color' : '#99ff99'})
    device_sensor(device)
    device["mobile_messages"] = []
        

# Interface to update and run the recipe
def execute_recipe():
    global run_status, target_rpm, previous_rpm, target_duration
    global recipe_cur_step, recipe_cur_rpm, recipe_cur_duration, start_time
    
    # if recipe not in run state the exit
    if run_status == False:
        return

    # take a current time stamp and exit if difference between previous and current less then 60 sec
    # as we are updating recipe every minute
    current_time = time.time()
    if (current_time - start_time) < 10:
        return

    # Copy the time at each minute for comprision or restart 1 min elapse calculation
    step_updated = False
    start_time = current_time

    # if duration in non_zero then only decrement
    if target_duration > 0:
        target_duration -= 1
    # Check if duration is zero then go to next step and reloop for zero setting 
    # if no futher duration setting and reached to last step the stop the recipe
    while target_duration == 0:
        recipe_cur_step += 1
        if recipe_cur_step >= TOTAL_STEPS_PER_RECIPE:
            recipe_cur_step = 0
            run_status = False    
            break
        if  run_status == True:
            update_recipe_step()
            step_updated = True

    # if recipe is finished then stop motor
    if run_status == False:
        target_rpm = 0
    # else if duration in non_zero then calculate next RPM for 1 min
    elif recipe_cur_duration > 0:
        if step_updated == False:
            target_rpm += (recipe_cur_rpm - previous_rpm) // recipe_cur_duration
            if target_rpm > (recipe_cur_rpm - ((recipe_cur_rpm - previous_rpm) // recipe_cur_duration)):
                target_rpm = recipe_cur_rpm
            print(target_duration)
            print(target_rpm)
    # output rpm on DAC (0-10v for 0 to 100.0%)
    write_analog(target_rpm)
    
# below codes are for above intercace checking purpose only
# need to be written on application side

def mixit(mode):
    if mode == 0:
        print("inside")
        config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 100, duration_in_min = 1)
        config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 200, duration_in_min = 2)
        config_recipe_steps(recepi_num = 1, step_num = 2, rpm_in_percent = 400, duration_in_min = 6)
        config_recipe_steps(recepi_num = 1, step_num = 3, rpm_in_percent = 700, duration_in_min = 8)
        config_recipe_steps(recepi_num = 1, step_num = 4, rpm_in_percent = 700, duration_in_min = 2)
        config_recipe_steps(recepi_num = 1, step_num = 5, rpm_in_percent = 0, duration_in_min = 0)
        start_recipe(recipe_num = 1, step_num = 1)
        stop_recipe()

    elif mode == 3:
        print("High")
        config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 100, duration_in_min = 1)
        config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 200, duration_in_min = 2)
        config_recipe_steps(recepi_num = 1, step_num = 2, rpm_in_percent = 400, duration_in_min = 6)
        config_recipe_steps(recepi_num = 1, step_num = 3, rpm_in_percent = 700, duration_in_min = 8)
        config_recipe_steps(recepi_num = 1, step_num = 4, rpm_in_percent = 700, duration_in_min = 2)
        config_recipe_steps(recepi_num = 1, step_num = 5, rpm_in_percent = 0, duration_in_min = 0)
        start_recipe(recipe_num = 1, step_num = 1)

        #stop_recipe()

    elif mode == 2:
        print("Medium")
        config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 400, duration_in_min = 2)
        config_recipe_steps(recepi_num = 1, step_num = 2, rpm_in_percent = 600, duration_in_min = 6)
        config_recipe_steps(recepi_num = 1, step_num = 3, rpm_in_percent = 700, duration_in_min = 8)
        config_recipe_steps(recepi_num = 1, step_num = 4, rpm_in_percent = 700, duration_in_min = 2)
        config_recipe_steps(recepi_num = 1, step_num = 5, rpm_in_percent = 0, duration_in_min = 0)
        start_recipe(recipe_num = 1, step_num = 1)
        #stop_recipe()

    elif mode == 1:
        print("Low")
        config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 500, duration_in_min = 2)
        config_recipe_steps(recepi_num = 1, step_num = 2, rpm_in_percent = 600, duration_in_min = 6)
        config_recipe_steps(recepi_num = 1, step_num = 3, rpm_in_percent = 700, duration_in_min = 8)
        config_recipe_steps(recepi_num = 1, step_num = 4, rpm_in_percent = 700, duration_in_min = 2)
        config_recipe_steps(recepi_num = 1, step_num = 5, rpm_in_percent = 0, duration_in_min = 0)
        start_recipe(recipe_num = 1, step_num = 1)
        #stop_recipe()
        

while True:
    time.sleep(0.4)
    mode_1 = check_with_simulator2(mode_1,'mode_1', sim_device)
    print(mode_1)
    print(mode_1)
    power_1 = check_with_simulator2(power_1,'power_1', sim_device)
    if power_1 == True:
        status_1 =1
    else:
        status_1 =0
    #print(status_1)
    rtm_1 = check_with_simulator2( rtm_1,'rtm_1', sim_device)
    #print(temperaturesensor_1)
    rpm_1 = rtm_1

    if status_1 == 1:
        

        if mode_1 > 0:
            print(type(mode_1))
            mixit(mode_1)
            '''if mode_1 == 1:
                mixit(1)
            elif mode_1 == 2:
                print("inside 2")
                mixit(2)
            elif mode_1 ==3:
                mixit(3)'''
            
        elif rpm_1 > 0:
            print(rpm_1)
            if rpm_1 > 650:
                config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 700, duration_in_min = 2)
                start_recipe(recipe_num = 1, step_num = 1)
            elif rpm_1 < 100:
                config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = 100, duration_in_min = 2)
                start_recipe(recipe_num = 1, step_num = 1)
            else:
                config_recipe_steps(recepi_num = 1, step_num = 1, rpm_in_percent = rpm_1, duration_in_min = 2)
                start_recipe(recipe_num = 1, step_num = 1)

        else:
            print("stop mode")
            mixit(0)

    else:
        print("stop switch")
        mixit(0)




            

    execute_recipe()


    
    