direction = None
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()

in3 = (19)
in4 = (26)
en2 = (16)
GPIO.setup(17,GPIO.IN)
GPIO.setup(18,GPIO.IN)
GPIO.setup(in3,GPIO.OUT)
GPIO.setup(in4,GPIO.OUT)
GPIO.setup(en2,GPIO.OUT)
GPIO.output(in3,GPIO.LOW)
GPIO.output(in4,GPIO.LOW)
p2=GPIO.PWM((16),1000)
p2.start(25)
def go_forward():
	#p2.ChangeDutyCycle(80)
	
	GPIO.output(in3,GPIO.HIGH)
	GPIO.output(in4,GPIO.LOW)
def go_backward():
	
	#p2.ChangeDutyCycle(80)
	GPIO.output(in3,GPIO.LOW)
	GPIO.output(in4,GPIO.HIGH)
def stop():
    

	GPIO.output(in3,GPIO.LOW)
	GPIO.output(in4,GPIO.LOW)
    
while True:
    IR_sensor_1 = not(GPIO.input(17))
    IR_sensor_2 = not(GPIO.input(18))

    
    if 'direction' in sim_device:
        direction = sim_device['direction']
        if direction == 'forward':
            
            if IR_sensor_1 == 1 :
                stop()
                time.sleep(1)
            elif IR_sensor_1 == 0:
                 go_forward()
                 time.sleep(1)                 
    
        elif direction == 'backward':
            if IR_sensor_2 == 1:
                stop()
                time.sleep(1)
            elif IR_sensor_2 == 0 :
                go_backward()
                time.sleep(1)

        elif direction == 'stop':
                 stop()
        time.sleep(0.5)
       