import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()

import time
import sys
import RPi.GPIO as GPIO

import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)


GPIO.setup((10), GPIO.OUT)
GPIO.setup((9), GPIO.OUT)
GPIO.setup((11), GPIO.OUT)
GPIO.setup((21), GPIO.OUT)
EMULATE_HX711=False

referenceUnit = 261

if not EMULATE_HX711:
    import RPi.GPIO as GPIO
    from hx711 import HX711
else:
    from emulated_hx711 import HX711

def cleanAndExit():
    print("Cleaning...")

    if not EMULATE_HX711:
        GPIO.cleanup()
        
    print("Bye!")
    sys.exit()

hx = HX711(25, 24)

hx.set_reading_format("MSB", "MSB")

hx.set_reference_unit(referenceUnit)

hx.reset()

hx.tare()

print("Tare done! Add weight now...")

def percentOfLiquidAValable():
    weight_val = hx.get_weight(5)
    print(weight_val)
    bottle_wt = 44
    percent_ofliquid = (weight_val)/484 *100
    hx.power_down()
    hx.power_up()
    return percent_ofliquid 
    
while True:
    val = int(percentOfLiquidAValable())
    print("Percentage :",val)
    print("--------------------------")
    device["mobile_messages"].append({'type' : 'text', 'value' : ('Percentage Available : ' + str(val)), 'color' : '#ffff99'})
    device["mobile_messages"].append({'type' : 'text','value' : '--------------------------------------------------------------','color' : '#ffffff'})
    device_sensor(device)
    device["mobile_messages"] = []
    
    if val > 70:
        GPIO.output(10, True)
    else:
        GPIO.output(10, False)
        
    if val <= 70 and val > 40:
        GPIO.output(9, True)
    else:
        GPIO.output(9, False)
    if val < 40:
        GPIO.output(11, True)
        GPIO.output(21, True)
        time.sleep(1)
        GPIO.output(21, False)
        
    else:
        GPIO.output(11, False)
    time.sleep(1)




