raindrop_sensor_1 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
GPIO.setup((7), GPIO.IN)
servo = (8)
GPIO.setup(servo,GPIO.OUT)
p=GPIO.PWM(servo,50)
p.start(2.5)
GPIO.setup((18), GPIO.OUT)
while True:
  raindrop_sensor_1 = (GPIO.input(7))
  raindrop_sensor_1 = check_with_simulator2(raindrop_sensor_1,'raindrop_sensor_1', sim_device)
  if raindrop_sensor_1 == 1:
    print('Raining')
    device["mobile_messages"].append({'type' : 'text','value' : 'Raining','color' : '#66ffff'})
    GPIO.output(18, True)
    time.sleep(0.1)
    p.ChangeDutyCycle(10)
    device["mobile_messages"].append({'type' : 'text','value' : 'Roof closed','color' : '#ffff33'})
    print('Roof closed')
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(5)
  elif raindrop_sensor_1 == 0:
    GPIO.output(18, False)
    time.sleep(0.1)
    p.ChangeDutyCycle(2.5)
    device["mobile_messages"].append({'type' : 'text','value' : 'Roof open','color' : '#ff6666'})
    print('Roof open')
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(1)