ultrasonic_1 = None
time_counter = 0
landslide = 0
landslide_timer = 0

import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
from rpi_lcd import LCD
lcd = LCD()

from grok_i2c_peripherals import init_i2c_bus
from grok_i2c_peripherals import read_adc
from grok_i2c_peripherals import write_analog
init_i2c_bus()

def calculate_distance(echo_pin,trigger_pin):
    GPIO.output(trigger_pin, True)
    time.sleep(0.00001)
    GPIO.output(trigger_pin, False)
    while GPIO.input(echo_pin) == 0:
        start = time.time()
    while GPIO.input(echo_pin) == 1:
        stop = time.time()
    measuredTime = stop - start
    distanceBothWays = measuredTime * 33112
    distance = distanceBothWays / 2
    print("Distance : {0:5.1f}cm".format(distance))
    return distance


def stop_servo():
  global irsensor_1, ultrasonic_1, irsensor_2
  ultrasonic_1 = calculate_distance((9),(10))
  
  if ultrasonic_1 < 10:
    p.ChangeDutyCycle(0)
    time.sleep(1)
    print('please wait someone is on turning')
    lcd.text("!! Vehicle ahead !!", 2)
    time.sleep(1)
  else:
    lcd.text("               ", 2)

import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

servo = (20)
GPIO.setup(servo,GPIO.OUT)
p=GPIO.PWM(servo,50)
p.start(2.5)

#Ultrasonic
GPIO.setup((9), GPIO.IN)
GPIO.setup((10), GPIO.OUT)

def rotate_echo():
  global time_counter
  time_counter += 1
  if time_counter == 5:
    p.ChangeDutyCycle(2)
    time.sleep(0.2)

  elif time_counter == 10:
    p.ChangeDutyCycle(5)
    time.sleep(0.2)

  elif time_counter == 15:
    p.ChangeDutyCycle(8)
    time.sleep(0.2)

  elif time_counter == 20:
    p.ChangeDutyCycle(11)
    time.sleep(0.2)

  elif time_counter == 25:
    p.ChangeDutyCycle(8)
    time.sleep(0.2)

  elif time_counter == 30:
    p.ChangeDutyCycle(5)
    time.sleep(0.2)

  elif time_counter == 35:
    p.ChangeDutyCycle(2)
    time.sleep(0.2)
    time_counter = 0

def Landslide_detect(analog_channel):
  global landslide, landslide_timer
  Value = read_adc(analog_channel)
  if Value != 0:
    Voltage = Value *5/1024
    vibr = abs(int((Voltage*1000) - 4882.8125))
    print("vibr : ",vibr)
    if vibr > 500:
      lcd.text("Landslide detected", 2)
      landslide = 1
      landslide_timer = 0
    
    if landslide == 1:
        landslide_timer += 1
        if landslide_timer > 50:
            landslide = 0
            lcd.text("              ", 2)
    
                      


while True:
  ultrasonic_1 = calculate_distance((9),(10))
  Landslide_detect(1)
  if ultrasonic_1 > 10:
    rotate_echo()
    lcd.text("               ", 1)
    
  elif ultrasonic_1 < 10:
    p.ChangeDutyCycle(0)
    print('please wait someone is on turning')
    lcd.text("Vehicle ahead !!", 1)
    time.sleep(4)