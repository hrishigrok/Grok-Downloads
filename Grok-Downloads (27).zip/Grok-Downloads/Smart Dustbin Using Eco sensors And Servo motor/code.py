ultrasonicsensor_1 = None
ultrasonicsensor_2 = None
waste_level = None


import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()

device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()

def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()


import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
GPIO.setup((24), GPIO.IN)
GPIO.setup((25), GPIO.OUT)
GPIO.setup((10), GPIO.IN)
GPIO.setup((9), GPIO.OUT)
def calculate_distance(echo_pin,trigger_pin):
	GPIO.output(trigger_pin, True)
	time.sleep(0.00001)
	GPIO.output(trigger_pin, False)

	while GPIO.input(echo_pin) == 0:
		start = time.time()
	while GPIO.input(echo_pin) == 1:
		stop = time.time()
	measuredTime = stop - start
	distanceBothWays = measuredTime * 33112
	distance = distanceBothWays / 2
	print("Distance : {0:5.1f}cm".format(distance))
	return distance
servo = (8)
GPIO.setup(servo,GPIO.OUT)
p=GPIO.PWM(servo,50)
p.start(2.5)
while True:
  ultrasonicsensor_1 = (calculate_distance((24),(25)))
  ultrasonicsensor_1 = check_with_simulator2(ultrasonicsensor_1,'ultrasonicsensor_1', sim_device)
  ultrasonicsensor_2 = (calculate_distance((10),(9)))
  ultrasonicsensor_2 = check_with_simulator2(ultrasonicsensor_2,'ultrasonicsensor_2', sim_device)
  if ultrasonicsensor_2 <= 20:
    if ultrasonicsensor_1 >= 5:
      p.ChangeDutyCycle(12)
      time.sleep(5)
      p.ChangeDutyCycle(0)
      time.sleep(0.2)
      print('Dustbin is open')
      device["mobile_messages"].append({'type' : 'text','value' : 'Dustbin is open','color' : '#33ff33'})

      device_sensor(device)
      device["mobile_messages"] = []
      while (calculate_distance((10),(9))) <= 20:
        time.sleep(1)
    else:
      p.ChangeDutyCycle(5)
      time.sleep(1)
      p.ChangeDutyCycle(0)
      time.sleep(0.2)
      print('Dustbin is full')
      device["mobile_messages"].append({'type' : 'text','value' : 'Dustbin is full','color' : '#ff0000'})

      device_sensor(device)
      device["mobile_messages"] = []
  else:
    waste_level = (ultrasonicsensor_1 / 15.9) * 100
    device["mobile_messages"].append({'type' : 'text', 'value' : (''.join([str(x) for x in ['Waste Level : ', round(float((100 - waste_level)), 2), ' % Full']])), 'color' : '#ffff00'})
    p.ChangeDutyCycle(5)
    time.sleep(0.5)
    p.ChangeDutyCycle(0)
    time.sleep(0.2)
    print('Dustbin is close')
    device["mobile_messages"].append({'type' : 'text','value' : 'Dustbin is close','color' : '#ff99ff'})

    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(0.2)
