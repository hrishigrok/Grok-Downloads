heartbeat_sensor_1_spo2 = None
heartbeat_sensor_1_hb = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import time
import max30100
mx30 = max30100.MAX30100()
mx30.enable_spo2()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup((11), GPIO.OUT)
GPIO.setup((9), GPIO.OUT)
GPIO.setup((10), GPIO.OUT)
GPIO.output(11, False)
GPIO.output(9, False)
GPIO.output(10, False)
time.sleep(2)
while True:
  mx30.read_sensor()
  mx30.ir, mx30.red
  heartbeat_sensor_1_spo2 = (int(mx30.red / 100)
  )
  heartbeat_sensor_1_spo2 = check_with_simulator2(heartbeat_sensor_1_spo2,'heartbeat_sensor_1_spo2', sim_device)
  heartbeat_sensor_1_hb = (int(mx30.ir / 100)
  )
  heartbeat_sensor_1_hb = check_with_simulator2(heartbeat_sensor_1_hb,'heartbeat_sensor_1_hb', sim_device)
  if heartbeat_sensor_1_spo2 != int(mx30.buffer_red[0] / 100):
    print(heartbeat_sensor_1_spo2)
    if heartbeat_sensor_1_spo2 >= 95:
      device["mobile_messages"].append({'type' : 'text','value' : 'Normal oxygen level','color' : '#33ffff'})
    else:
      device["mobile_messages"].append({'type' : 'text','value' : 'Low oxygen level','color' : '#ff6666'})
  if heartbeat_sensor_1_hb != int(mx30.buffer_ir[0] / 100):
    print(heartbeat_sensor_1_hb)
    if heartbeat_sensor_1_hb > 100:
      GPIO.output(11, True)
      device["mobile_messages"].append({'type' : 'text','value' : 'Heartbeats above 100, LED3 turning ON','color' : '#ff0000'})
    else:
      GPIO.output(11, False)
      device["mobile_messages"].append({'type' : 'text','value' : 'Heartbeats not above 100, LED3 turning OFF','color' : '#33ff33'})
    if heartbeat_sensor_1_hb > 90:
      GPIO.output(9, True)
      device["mobile_messages"].append({'type' : 'text','value' : 'Heartbeats above 90, LED2 turning ON','color' : '#ff0000'})
    else:
      GPIO.output(9, False)
      device["mobile_messages"].append({'type' : 'text','value' : 'Heartbeats not above 90, LED2 turning OFF','color' : '#33ff33'})
    if heartbeat_sensor_1_hb > 80:
      GPIO.output(10, True)
      device["mobile_messages"].append({'type' : 'text','value' : 'Heartbeats above 80, LED1 turning ON','color' : '#ff0000'})
    else:
      GPIO.output(10, False)
      device["mobile_messages"].append({'type' : 'text','value' : 'Heartbeats not above 80, LED1 turning OFF','color' : '#33ff33'})
    device["mobile_messages"].append({'type' : 'text','value' : '---','color' : '#33ff33'})
    device_sensor(device)
    device["mobile_messages"] = []
  time.sleep(2)