allowed = None
Count = None
Servo_1 = None
servo_2 = None
irsensor_1 = None
irsensor_2 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
allowed = 5
Count = 0
GPIO.setup((7), GPIO.IN)
GPIO.setup((16), GPIO.IN)
GPIO.setup((8),GPIO.OUT)
Servo_1=GPIO.PWM((8),50)
Servo_1.start(2.5)
GPIO.setup((17),GPIO.OUT)
servo_2=GPIO.PWM((17),50)
servo_2.start(2.5)
Servo_1.ChangeDutyCycle(10)
servo_2.ChangeDutyCycle(10)
while True:
  irsensor_1 = GPIO.input(7)
  irsensor_2 = GPIO.input(16)
  if irsensor_1 and irsensor_2:
    device["mobile_messages"].append({'type' : 'text','value' : 'Wait for person to exit','color' : '#33ff33'})
    device_sensor(device)
    device["mobile_messages"] = []
  if irsensor_1 and Count < allowed:
    Count = Count + 1
    Servo_1.ChangeDutyCycle(5)
    time.sleep(2)
    Servo_1.ChangeDutyCycle(10)
    time.sleep(0.9)
    Servo_1.ChangeDutyCycle(0)
    time.sleep(0.4)
  if irsensor_2:
    Count = Count - 1
    servo_2.ChangeDutyCycle(5)
    time.sleep(2)
    servo_2.ChangeDutyCycle(10)
    time.sleep(0.9)
    servo_2.ChangeDutyCycle(0)
    time.sleep(0.4)
  if Count >= allowed:
    device["mobile_messages"].append({'type' : 'text','value' : 'No More People Allowed','color' : '#ffcccc'})
    device_sensor(device)
    device["mobile_messages"] = []
  device["mobile_messages"].append({'type' : 'text', 'value' : ('People Inside : ' + str(Count)), 'color' : '#33ff33'})
  device_sensor(device)
  device["mobile_messages"] = []
  Servo_1.ChangeDutyCycle(0)
  servo_2.ChangeDutyCycle(0)
  time.sleep(0.3)