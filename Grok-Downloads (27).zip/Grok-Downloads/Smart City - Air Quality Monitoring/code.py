pm2_5 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import serial
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
ser = serial.Serial('/dev/ttyUSB0', 9600)

def readsds01Sensor():
    data = ser.read(10)
    if data[0] == 170 and data[1] == 192:
        pm25 = (data[3] * 256 + data[2]) / 10.0
    else:
        pm25 = 0
    return pm25
    
GPIO.setup((24), GPIO.OUT)
GPIO.setup((25), GPIO.OUT)
GPIO.setup((27), GPIO.OUT)

GPIO.output(25, True)
while True:
  pm2_5 = readsds01Sensor()
  print(pm2_5)
  device["mobile_messages"].append({'type' : 'text', 'value' : ('PM2.5 : ' + str(pm2_5)), 'color' : '#ffffcc'})
  if pm2_5 <= 50:
    GPIO.output(24, True)
    GPIO.output(25, False)
    GPIO.output(27, False)
    device["mobile_messages"].append({'type' : 'text','value' : 'Air Quality : Good','color' : '#99ff99'})
  elif pm2_5 > 50 and pm2_5 < 100:
    GPIO.output(24, False)
    GPIO.output(25, True)
    GPIO.output(27, False)
    device["mobile_messages"].append({'type' : 'text','value' : 'Air Quality : Moderate','color' : '#ffff99'})
  else:
    GPIO.output(24, False)
    GPIO.output(25, False)
    GPIO.output(27, True)
    device["mobile_messages"].append({'type' : 'text','value' : 'Air Quality : Unhealthy','color' : '#ffcccc'})
  device_sensor(device)
  device["mobile_messages"] = []
  time.sleep(2)

