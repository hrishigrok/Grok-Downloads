key = None
password = None
keypad_1 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
import os

import subprocess, sys, os


def install(package):
    if(type(package)==str):
        try:
            __import__(package)
        except ImportError as err:
            try:
                os.system(f'python3 -m pip install {package}')
                __import__(package)
                print(f"\n{package.upper()} Module has been installed and imported\n")
            except ModuleNotFoundError as er:
                print(er.msg)
        else:
            print("Module has been imported")
    else: 
        print("Please Enter a valid Package Name")
install('wget')

import wget


key = None
password = '35298'
keypad_1 = ''
R1 = (16)
R2 = (17)
R3 = (18)
R4 = (20)
GPIO.setup(R1, GPIO.OUT)
GPIO.setup(R2, GPIO.OUT)
GPIO.setup(R3, GPIO.OUT)
GPIO.setup(R4, GPIO.OUT)
C1 = (21)
C2 = (24)
C3 = (25)
C4 = (27)
GPIO.setup(C1, GPIO.IN)
GPIO.setup(C2, GPIO.IN)
GPIO.setup(C3, GPIO.IN)
GPIO.setup(C4, GPIO.IN)

def readRow(line, characters):
    global key
    GPIO.output(line, GPIO.LOW)
    time.sleep(0.04)
    if(GPIO.input(C1) == 0):
        key = characters[0]
    if(GPIO.input(C2) == 0):
        key = characters[1]
    if(GPIO.input(C3) == 0):
        key = characters[2]
    if(GPIO.input(C4) == 0):
        key = characters[3]
    GPIO.output(line, GPIO.HIGH)
def readKey():
    readRow(R1, ["1","2","3","A"])
    readRow(R2, ["4","5","6","B"])
    readRow(R3, ["7","8","9","C"])
    readRow(R4, ["*","0","#","D"])

while True:
  while key == None:
    if 'keypad_1' in sim_device:
      keypad_1 = sim_device['keypad_1']
      key = ''
      del sim_device['keypad_1']
    else:
      readKey()
  if key == 'C':
    device["mobile_messages"].append({'type' : 'text','value' : 'Reset','color' : '#ffffff'})
    device_sensor(device)
    device["mobile_messages"] = []
    keypad_1 = ''
    time.sleep(0.2)
  else:
    keypad_1 = str(keypad_1) + str(key)
    print('Key pressed')
    device["mobile_messages"].append({'type' : 'text','value' : 'Key pressed','color' : '#ffffff'})
    if len(keypad_1) >= len(password):
      if keypad_1 == password:

        # Update Programs
        if os.path.exists("/home/pi/Desktop/Grok-Downloads.zip"):
          os.remove("/home/pi/Desktop/Grok-Downloads.zip")

  
        # To Download Zip
        Zip_url='https://comms.grokstem.com/wp/wp-content/uploads/Grok-Downloads.zip'
        Zip_path = '/home/pi/Desktop'
        wget.download(Zip_url,out = Zip_path)

        # Unzip the File
        from zipfile import ZipFile
        with ZipFile("/home/pi/Desktop/Grok-Downloads.zip", 'r') as zObject:
            zObject.extractall(
                path="/home/pi/Desktop")
    
        if os.path.exists("/home/pi/Desktop/Grok-Downloads.zip"):
          os.remove("/home/pi/Desktop/Grok-Downloads.zip")        


        device["mobile_messages"].append({'type' : 'text','value' : 'Programs Updated','color' : '#99ff99'})
        device_sensor(device)
        device["mobile_messages"] = []
        
      else:
        print('Wrong password')
        device["mobile_messages"].append({'type' : 'text','value' : 'Wrong password','color' : '#ffcccc'})

        #click picture
        device_sensor(device)
        device["mobile_messages"] = []


      keypad_1 = ''
    else:
      device["mobile_messages"].append({'type' : 'text','value' : 'Incomplete password','color' : '#ffffff'})
      device_sensor(device)
      device["mobile_messages"] = []
  key = None
  time.sleep(0.4)