import os
import wget
import time



if os.path.exists("/home/pi/Desktop/Grok-Downloads.zip"):
  os.remove("/home/pi/Desktop/Grok-Downloads.zip")

  
# To Download Zip
Zip_url='https://comms.grokstem.com/wp/wp-content/uploads/2023/01/Grok-Downloads.zip'
Zip_path = '/home/pi/Desktop'
wget.download(Zip_url,out = Zip_path)

# Unzip the File
from zipfile import ZipFile
with ZipFile("/home/pi/Desktop/Grok-Downloads.zip", 'r') as zObject:
    zObject.extractall(
        path="/home/pi/Desktop")
    
if os.path.exists("/home/pi/Desktop/Grok-Downloads.zip"):
  os.remove("/home/pi/Desktop/Grok-Downloads.zip")

