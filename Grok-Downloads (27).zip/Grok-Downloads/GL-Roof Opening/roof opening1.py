import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
in1 = (6)
in2 = (13)
in3 = (19)
in4 = (26)
en1 = (20)
en2 = (16)
GPIO.setup(in1,GPIO.OUT)
GPIO.setup(in2,GPIO.OUT)
GPIO.setup(en1,GPIO.OUT)
GPIO.setup(in3,GPIO.OUT)
GPIO.setup(in4,GPIO.OUT)
GPIO.setup(en2,GPIO.OUT)
GPIO.output(in1,GPIO.LOW)
GPIO.output(in2,GPIO.LOW)
GPIO.output(in3,GPIO.LOW)
GPIO.output(in4,GPIO.LOW)
p1=GPIO.PWM((20),1000)
p1.start(25)
p2=GPIO.PWM((16),1000)
p2.start(25)
def go_forward():
	p2.ChangeDutyCycle(80)
	p1.ChangeDutyCycle(80)
	GPIO.output(in1,GPIO.LOW)
	GPIO.output(in2,GPIO.HIGH)
	GPIO.output(in3,GPIO.LOW)
	GPIO.output(in4,GPIO.HIGH)
def go_backward():
	p1.ChangeDutyCycle(80)
	p2.ChangeDutyCycle(80)
	GPIO.output(in1,GPIO.HIGH)
	GPIO.output(in2,GPIO.LOW)
	GPIO.output(in3,GPIO.HIGH)
	GPIO.output(in4,GPIO.LOW)
def stop():
	GPIO.output(in1,GPIO.LOW)
	GPIO.output(in2,GPIO.LOW)
	GPIO.output(in3,GPIO.LOW)
	GPIO.output(in4,GPIO.LOW)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
GPIO.setup((7), GPIO.IN)
GPIO.setup((27), GPIO.OUT)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
flag=1
while True:
  raindrop_sensor_1 = (GPIO.input(7))
  if flag==1:
      if raindrop_sensor_1 == 1:
          print('raining')
          GPIO.output(27, True)
          time.sleep(0.1)
          print('turn on roof')
          go_forward()
          time.sleep(6)
          flag=0
          stop()

  elif flag==0:
     if raindrop_sensor_1 == 0:
          print('not raining')
          GPIO.output(27, False)
          time.sleep(0.1)
          print('turn off roof')  
          go_backward()
          time.sleep(6)
          flag=1
          stop()
          

