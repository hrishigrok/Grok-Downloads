dispense_amount = None
rice = None
wheat = None
pulses = None
measured_weight = None
key = None

# Describe this function...
def grains_dispensor2(dispense_amount, rice, wheat, pulses):
  global measured_weight, key
  if rice == True:
    disp_rice(dispense_amount)
  if wheat == True:
    disp_wheat(dispense_amount)
  if pulses == True:
    disp_pulses(dispense_amount)
  lcd_display_I2C.clear()
  lcd_display_I2C.text('Order Completed!', 1)
  time.sleep(2)

# Describe this function...
def disp_rice(dispense_amount):
  global rice, wheat, pulses, measured_weight, key
  measured_weight = hx.get_weight(5)

  readKey()
  key = ''
  lcd_display_I2C.clear()
  lcd_display_I2C.text('Rice', 1)
  lcd_display_I2C.text('A-Disp D-Skip   ', 2)
  while key != 'A' and key != 'D':
    readKey()
    time.sleep(0.2)
  if key == 'A':
    GPIO.output(22, GPIO.HIGH)
    while ((hx.get_weight(5)
    ) - measured_weight) / 0.7 <= dispense_amount:
      lcd_display_I2C.clear()
      lcd_display_I2C.text('Rice Dispensing...', 1)
      print('Rice Dispensing...')
      time.sleep(0.2)
    GPIO.output(22, GPIO.LOW)
    lcd_display_I2C.clear()
    lcd_display_I2C.text('Empty Container', 1)
    key = ''
  if key == 'D':
    lcd_display_I2C.clear()
    lcd_display_I2C.text('Skipped', 1)
    time.sleep(1)
  time.sleep(4)
  lcd_display_I2C.clear()

# Describe this function...
def disp_wheat(dispense_amount):
  global rice, wheat, pulses, measured_weight, key
  measured_weight = hx.get_weight(5)

  readKey()
  key = ''
  lcd_display_I2C.clear()
  lcd_display_I2C.text('Wheat', 1)
  lcd_display_I2C.text('A-Disp D-Skip   ', 2)
  while key != 'A' and key != 'D':
    readKey()
    time.sleep(0.2)
  if key == 'A':
    GPIO.output(23, GPIO.HIGH)
    while ((hx.get_weight(5)
    ) - measured_weight) / 0.7 <= dispense_amount:
      lcd_display_I2C.clear()
      lcd_display_I2C.text('Wheat Dispensing...', 1)
      print('Wheat Dispensing...')
      time.sleep(0.2)
    GPIO.output(23, GPIO.LOW)
    lcd_display_I2C.clear()
    lcd_display_I2C.text('Empty Container', 1)
    key = ''
  if key == 'D':
    lcd_display_I2C.clear()
    lcd_display_I2C.text('Skipped', 1)
    time.sleep(1)
  time.sleep(4)
  lcd_display_I2C.clear()

# Describe this function...
def disp_pulses(dispense_amount):
  global rice, wheat, pulses, measured_weight, key
  measured_weight = hx.get_weight(5)

  readKey()
  key = ''
  lcd_display_I2C.clear()
  lcd_display_I2C.text('Pulses', 1)
  lcd_display_I2C.text('A-Disp D-Skip   ', 2)
  while key != 'A' and key != 'D':
    readKey()
    time.sleep(0.2)
  if key == 'A':
    GPIO.output(8, GPIO.HIGH)
    while ((hx.get_weight(5)
    ) - measured_weight) / 0.7 <= dispense_amount:
      lcd_display_I2C.clear()
      lcd_display_I2C.text('Pulses Dispensing...', 1)
      time.sleep(0.2)
      print('Pulses Dispensing...')
    GPIO.output(8, GPIO.LOW)
    lcd_display_I2C.clear()
    lcd_display_I2C.text('Empty Container', 1)
    key = ''
  if key == 'D':
    lcd_display_I2C.clear()
    lcd_display_I2C.text('Skipped', 1)
    time.sleep(1)
  time.sleep(4)
  lcd_display_I2C.clear()


import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()

device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()

def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()


import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import sys
sys.path.append('/home/pi/Desktop/Grok-Downloads/Custom_lib')
EMULATE_HX711=False
referenceUnit = 261
if not EMULATE_HX711:
	import RPi.GPIO as GPIO
	from hx711 import HX711
else:
	from emulated_hx711 import HX711
def cleanAndExit():
	print("Cleaning...")
	if not EMULATE_HX711:
		GPIO.cleanup()
	print("Bye!")
	sys.exit()
import time
from rpi_lcd import LCD
lcd_display_I2C = LCD()
key = None

R1 = (16)
R2 = (17)
R3 = (18)
R4 = (20)

GPIO.setup(R1, GPIO.OUT)
GPIO.setup(R2, GPIO.OUT)
GPIO.setup(R3, GPIO.OUT)
GPIO.setup(R4, GPIO.OUT)

C1 = (21)
C2 = (24)
C3 = (25)
C4 = (27)

GPIO.setup(C1, GPIO.IN)
GPIO.setup(C2, GPIO.IN)
GPIO.setup(C3, GPIO.IN)
GPIO.setup(C4, GPIO.IN)

def readRow(line, characters):
    global key
    GPIO.output(line, GPIO.LOW)
    time.sleep(0.04)
    if(GPIO.input(C1) == 0):
        key = characters[0]
    if(GPIO.input(C2) == 0):
        key = characters[1]
    if(GPIO.input(C3) == 0):
        key = characters[2]
    if(GPIO.input(C4) == 0):
        key = characters[3]
    GPIO.output(line, GPIO.HIGH)

def readKey():
    readRow(R1, ["1","2","3","A"])
    readRow(R2, ["4","5","6","B"])
    readRow(R3, ["7","8","9","C"])
    readRow(R4, ["*","0","#","D"])
hx = HX711((9),(10))
hx.set_reading_format("MSB", "MSB")
hx.set_reference_unit(referenceUnit)
hx.reset()
hx.tare()
print("Tare done! Add weight now...")
GPIO.setup((22), GPIO.OUT)
GPIO.output((22), GPIO.HIGH)
GPIO.setup((23), GPIO.OUT)
GPIO.output((23), GPIO.HIGH)
GPIO.setup((8), GPIO.OUT)
GPIO.output((8), GPIO.HIGH)
GPIO.output(22, GPIO.LOW)
GPIO.output(23, GPIO.LOW)
GPIO.output(8, GPIO.LOW)
while True:
  readKey()
  print(key)
  if key == '1':
    lcd_display_I2C.text('User-1', 1)
    lcd_display_I2C.text('Alloted : 100g', 2)
    time.sleep(2)
    print('dispense  100gm')
    device["mobile_messages"].append({'type' : 'text','value' : 'dispense  100gm','color' : '#ffff00'})
    grains_dispensor2(100, True, True, True)
    print('dispensed  100gm')
    device["mobile_messages"].append({'type' : 'text','value' : 'dispensed  100gm','color' : '#ff0000'})

    device_sensor(device)
    device["mobile_messages"] = []
  elif key == '2':
    lcd_display_I2C.text('User-2', 1)
    lcd_display_I2C.text('Alloted : 200g', 2)
    time.sleep(2)
    print('dispense  200gm')
    device["mobile_messages"].append({'type' : 'text','value' : 'dispense  200gm','color' : '#ffff00'})
    grains_dispensor2(200, True, False, True)
    print('dispensed 500gm')
    device["mobile_messages"].append({'type' : 'text','value' : 'dispensed 200gm','color' : '#ff0000'})

    device_sensor(device)
    device["mobile_messages"] = []
  key = None
  lcd_display_I2C.text('Enter Your ID', 1)
  time.sleep(0.4)
