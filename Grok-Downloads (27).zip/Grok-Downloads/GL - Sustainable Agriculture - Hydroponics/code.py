temperaturesensor_1 = None
rtc_1 = None
ph_sensor_1 = None
tds_sensor_1 = None


import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()

device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()

def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()


import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import Adafruit_DHT
from grok_i2c_peripherals import init_i2c_bus
from grok_i2c_peripherals import init_rtc
from grok_i2c_peripherals import rtc_read_time
from grok_i2c_peripherals import rtc_read_date_str
from grok_i2c_peripherals import rtc_read_time_str
from grok_i2c_peripherals import rtc_write_time
from grok_i2c_peripherals import rtc_write_date
from grok_i2c_peripherals import init_i2c_bus
from grok_i2c_peripherals import read_adc
from grok_i2c_peripherals import write_analog
init_i2c_bus()
from grok_i2c_peripherals import init_i2c_bus
from grok_i2c_peripherals import read_adc
from grok_i2c_peripherals import write_analog
init_i2c_bus()

import time
GPIO.setup((24), GPIO.OUT)
GPIO.output((24), GPIO.HIGH)
GPIO.setup((25), GPIO.OUT)
GPIO.output((25), GPIO.HIGH)
GPIO.setup((27), GPIO.OUT)
GPIO.output((27), GPIO.HIGH)
GPIO.setup((21), GPIO.IN)

init_i2c_bus()
time.sleep(1)
init_rtc()
time.sleep(0.2)

def calculate_current_time():
    hour = str(rtc_read_time()[0])
    minute = str(rtc_read_time()[1])
    second = str(rtc_read_time()[2])
    current_time = hour + ':' + minute
    return current_time


def tdsValue(analog_channel):
	Value = read_adc(analog_channel)
	if Value != 0:
		Voltage = Value *5/1024
		tds = int((133.42/Voltage*Voltage*Voltage - 255.86*Voltage*Voltage + 857.39*Voltage)*0.5)
		return tds

def phValue(analog_channel):
	Value = read_adc(analog_channel)
	if Value != 0:
		Voltage = Value *6/1024
		ph = ((3.91007-Voltage)/0.18)
		return ph
GPIO.output(25, GPIO.LOW)
device["mobile_messages"].append({'type' : 'text','value' : 'Water pump ON','color' : '#cc33cc'})
while True:
  humidity, temperature = Adafruit_DHT.read_retry(Adafruit_DHT.DHT11,(21))
  temperaturesensor_1 = ( temperature
  )
  temperaturesensor_1 = check_with_simulator2(temperaturesensor_1,'temperaturesensor_1', sim_device)
  rtc_1 = (calculate_current_time()
  )
  rtc_1 = check_with_simulator2(rtc_1,'rtc_1', sim_device)
  ph_sensor_1 = (phValue(1)
  )
  ph_sensor_1 = check_with_simulator2(ph_sensor_1,'ph_sensor_1', sim_device)
  tds_sensor_1 = (tdsValue(2)
  )
  tds_sensor_1 = check_with_simulator2(tds_sensor_1,'tds_sensor_1', sim_device)
  device["mobile_messages"].append({'type' : 'text','value' : '-----------------------------------','color' : '#ffffff'})
  device["mobile_messages"].append({'type' : 'text', 'value' : ('Current Time ' + str(rtc_1)), 'color' : '#cc33cc'})
  print(rtc_1)
  rtc_1 = rtc_1.split(':')
  rtc_1 = int((rtc_1[0]))
  if temperaturesensor_1 > 25:
    GPIO.output(24, GPIO.LOW)
    print('Cooling Turned ON')
    device["mobile_messages"].append({'type' : 'text','value' : 'Cooling Turned ON','color' : '#ff0000'})
  else:
    GPIO.output(24, GPIO.HIGH)
    print('Cooling Turned OFF')
    device["mobile_messages"].append({'type' : 'text','value' : 'Cooling Turned OFF','color' : '#33ff33'})
  if rtc_1 >= 6 and rtc_1 <= 18:
    GPIO.output(27, GPIO.LOW)
    device["mobile_messages"].append({'type' : 'text','value' : 'Lights ON','color' : '#ff0000'})
  else:
    GPIO.output(27, GPIO.HIGH)
    device["mobile_messages"].append({'type' : 'text','value' : 'Lights OFF','color' : '#33ff33'})
  device["mobile_messages"].append({'type' : 'text', 'value' : ('Temperature' + str(temperaturesensor_1)), 'color' : '#99ffff'})
  device["mobile_messages"].append({'type' : 'text', 'value' : ('TDS' + str(tds_sensor_1)), 'color' : '#ffff33'})
  device["mobile_messages"].append({'type' : 'text', 'value' : ('pH' + str(ph_sensor_1)), 'color' : '#009900'})

  device_sensor(device)
  device["mobile_messages"] = []
  time.sleep(1)
