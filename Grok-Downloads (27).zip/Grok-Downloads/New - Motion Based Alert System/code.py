irsensor_1 = None
import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()
def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time
GPIO.setup((7), GPIO.IN)
GPIO.setup((18), GPIO.OUT)
while True:
  irsensor_1 = (GPIO.input(7))
  irsensor_1 = check_with_simulator2(irsensor_1,'irsensor_1', sim_device)
  if irsensor_1 == 1:
    print('Motion detected')
    device["mobile_messages"].append({'type' : 'text','value' : 'Motion detected','color' : '#33ff33'})
    GPIO.output(18, True)
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(2)
  elif irsensor_1 == 0:
    print('No Motion detected')
    device["mobile_messages"].append({'type' : 'text','value' : 'No Motion detected','color' : '#ff0000'})
    GPIO.output(18, False)
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(1)