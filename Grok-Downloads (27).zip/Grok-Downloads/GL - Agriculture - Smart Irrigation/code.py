Rdata = None
Did = None
status = None
moisturesensor_1 = None

import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()
device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()

def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors

def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()
import serial
import time
Rdata = ''
Did = ''
status = ''

ser=serial.Serial("/dev/ttyUSB0",115200)

def readSensor():
    try:
        readedText = ser.readline().decode('utf-8').rstrip()
        time.sleep(0.1)
        data = readedText.split(" ")
        ser.flush()
        if len(data) == 2 and type(data) != type(None):
            return data

    except:
        pass
    return "0 0"

while True:
  data =  readSensor()
  Did = data[0]
  status = data[1]
  print("Did :",Did)
  print("stat :",status)

  if Did == 'A':
    moisturesensor_1 = status
    moisturesensor_1 = int(moisturesensor_1)
    
  moisturesensor_1 = check_with_simulator2(moisturesensor_1,'moisturesensor_1', sim_device)

  if moisturesensor_1 == 1:
    print('Moisture Detected, Irrigation OFF')
    device["mobile_messages"].append({'type' : 'text','value' : 'Moisture Detected, Irrigation OFF','color' : '#33ff33'})
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(0.2)
    ser.write(b"C 0\n")

  elif moisturesensor_1 == 0:
    print('Moisture Not Detected, Irrigation ON')
    device["mobile_messages"].append({'type' : 'text','value' : 'Moisture Not Detected, Irrigation ON','color' : '#33ffff'})
    device_sensor(device)
    device["mobile_messages"] = []
    time.sleep(0.2)
    ser.write(b"C 1\n")
    
  time.sleep(1)

