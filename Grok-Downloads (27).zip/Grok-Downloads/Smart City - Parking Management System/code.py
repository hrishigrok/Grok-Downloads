irsensor_1 = None
irsensor_2 = None
irsensor_3 = None
irsensor_4 = None
irsensor_5 = None
Available_slots = None


import sys, os
HOME        = os.path.expanduser('~')
RPI_HOME    = HOME + '/RPI/'
GROK_HOME   = HOME + '/Desktop/Grok-Downloads/'
sys.path.insert(1, RPI_HOME)
from file_watcher import FileWatcher, device_sensor
from grok_library import check_with_simulator,check_with_simulator2, device, sim_device, pin, GrokLib
import threading
grokLib = GrokLib()

device['applicationIdentifier'] = str(os.path.splitext(os.path.basename(__file__))[0])
device['mobile_messages'] = list()

def simulate(list_of_sensors):
    if list_of_sensors is not None:
        global sim_device
        sim_device = list_of_sensors
def startListener1():
    FileWatcher(simulate, 'simulation.json', RPI_HOME, 'config_file')
thread1 = threading.Thread(target=startListener1, args=())
thread1.daemon=True
thread1.start()


import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import RPi.GPIO as GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
import time

GPIO.setup((7), GPIO.IN)
GPIO.setup((8), GPIO.IN)
GPIO.setup((16), GPIO.IN)
GPIO.setup((17), GPIO.IN)
GPIO.setup((18), GPIO.IN)
GPIO.setup((24), GPIO.OUT)
GPIO.setup((27), GPIO.OUT)
servo = (20)
GPIO.setup(servo,GPIO.OUT)
p=GPIO.PWM(servo,50)
p.start(2.5)

servo2 = (21)
GPIO.setup(servo2,GPIO.OUT)
p2=GPIO.PWM(servo2,50)
p2.start(2.5)

p.ChangeDutyCycle(5)
p2.ChangeDutyCycle(5)

while True:
  irsensor_1 = (GPIO.input(8))
  irsensor_1 = check_with_simulator2(irsensor_1,'irsensor_1', sim_device)
  irsensor_2 = (GPIO.input(16))
  irsensor_2 = check_with_simulator2(irsensor_2,'irsensor_2', sim_device)
  irsensor_3 = (GPIO.input(17))
  irsensor_3 = check_with_simulator2(irsensor_3,'irsensor_3', sim_device)
  irsensor_4 = (GPIO.input(18))
  irsensor_4 = check_with_simulator2(irsensor_4,'irsensor_4', sim_device)
  irsensor_5 = (GPIO.input(7))
  irsensor_5 = check_with_simulator2(irsensor_5,'irsensor_5', sim_device)
  Available_slots = irsensor_1 + (irsensor_2 + irsensor_3)
  if Available_slots >= 3:
    GPIO.output(24, False)
    GPIO.output(27, True)
    print('No Parking Slots Available')
    device["mobile_messages"].append({'type' : 'text','value' : 'No Parking Slots Available','color' : '#ffcccc'})
  elif Available_slots < 3:
    if irsensor_1 == 0 and irsensor_2 == 0 and irsensor_3 == 0:
      print('All Parking Slots Available')
      device["mobile_messages"].append({'type' : 'text','value' : 'All Parking Slots Available','color' : '#99ff99'})
    elif irsensor_1 == 0 and irsensor_2 == 0 and irsensor_3 == 1:
      print('Parking-1 and Parking-2 Available')
      device["mobile_messages"].append({'type' : 'text','value' : 'Parking-1 and Parking-2 Available','color' : '#ffffcc'})
    elif irsensor_1 == 0 and irsensor_2 == 1 and irsensor_3 == 1:
      print('Parking-1 Available')
      device["mobile_messages"].append({'type' : 'text','value' : 'Parking-1 Available','color' : '#ffffcc'})
    elif irsensor_1 == 1 and irsensor_2 == 0 and irsensor_3 == 1:
      print('Parking-2 Available')
      device["mobile_messages"].append({'type' : 'text','value' : 'Parking-2 Available','color' : '#ffffcc'})
    elif irsensor_1 == 1 and irsensor_2 == 1 and irsensor_3 == 0:
      print('Parking-3 Available')
      device["mobile_messages"].append({'type' : 'text','value' : 'Parking-3 Available','color' : '#ffffcc'})
    elif irsensor_1 == 1 and irsensor_2 == 0 and irsensor_3 == 0:
      print('Parking-2 and Parking-3 Available')
      device["mobile_messages"].append({'type' : 'text','value' : 'Parking-2 and Parking-3 Available','color' : '#ffffcc'})
    elif irsensor_1 == 0 and irsensor_2 == 1 and irsensor_3 == 0:
      print('Parking-1 and Parking-3 Available')
      device["mobile_messages"].append({'type' : 'text','value' : 'Parking-1 and Parking-3 Available','color' : '#ffffcc'})
    GPIO.output(27, False)
    GPIO.output(24, True)
    if irsensor_4 == 1:
      p.ChangeDutyCycle(10)
      time.sleep(0.8)
      p.ChangeDutyCycle(0)
      print('Entry Gate Opened....Vehicle In !!')
      device["mobile_messages"].append({'type' : 'text','value' : 'Entry Gate Opened....Vehicle In !!','color' : '#99ffff'})
      time.sleep(3)
      p.ChangeDutyCycle(5)
      time.sleep(0.8)
      p.ChangeDutyCycle(0)
  if irsensor_5 == 1:
    p2.ChangeDutyCycle(0)
    time.sleep(0.8)
    p2.ChangeDutyCycle(10)
    print('Exit Gate Opened....Vehicle Out !!')
    device["mobile_messages"].append({'type' : 'text','value' : 'Exit Gate Opened....Vehicle Out !!','color' : '#ffff00'})
    time.sleep(3)
    p2.ChangeDutyCycle(0)
    time.sleep(0.8)
    p2.ChangeDutyCycle(5)

  device_sensor(device)
  device["mobile_messages"] = []
  time.sleep(1)
